"""
train_model.py
--------------
Trains a GradientBoosting fraud detection model on synthetic data
and saves the artefact to model/fraud_model.pkl.

Run once before building the Docker image:
    python model/train_model.py
"""

import numpy as np
import joblib
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

# ── Synthetic dataset ──────────────────────────────────────────────────────
np.random.seed(42)
N = 5000

# Features: amount, hour_of_day, distance_from_home, num_transactions_24h,
#           is_foreign, is_online
X = np.column_stack([
    np.random.exponential(scale=200, size=N),          # amount
    np.random.randint(0, 24, size=N),                  # hour_of_day
    np.random.exponential(scale=50, size=N),           # distance_from_home (km)
    np.random.poisson(lam=3, size=N),                  # num_transactions_24h
    np.random.binomial(1, 0.2, size=N),                # is_foreign
    np.random.binomial(1, 0.5, size=N),                # is_online
])

# Fraud label: higher amount + foreign + odd hours = more likely fraud
fraud_score = (
    0.003 * X[:, 0] +
    0.4   * X[:, 4] +
    0.3   * (X[:, 1] < 6).astype(float) +
    0.2   * X[:, 5]
)
y = (fraud_score + np.random.normal(0, 0.3, N) > 1.0).astype(int)

print(f"Dataset: {N} samples | Fraud rate: {y.mean():.1%}")

# ── Model pipeline ─────────────────────────────────────────────────────────
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

pipeline = Pipeline([
    ("scaler", StandardScaler()),
    ("model", GradientBoostingClassifier(
        n_estimators=200,
        learning_rate=0.05,
        max_depth=4,
        random_state=42,
    ))
])

pipeline.fit(X_train, y_train)
y_pred = pipeline.predict(X_test)

print("\nClassification Report:")
print(classification_report(y_test, y_pred, target_names=["Legit", "Fraud"]))

# ── Save artefact ──────────────────────────────────────────────────────────
import os
os.makedirs("model", exist_ok=True)
joblib.dump(pipeline, "model/fraud_model.pkl")
print("Model saved to model/fraud_model.pkl")
