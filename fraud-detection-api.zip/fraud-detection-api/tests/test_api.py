"""
tests/test_api.py
-----------------
Unit and integration tests for the Fraud Detection API.
"""

import pytest
from fastapi.testclient import TestClient
import joblib
import numpy as np
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import GradientBoostingClassifier
from unittest.mock import patch, MagicMock

from app.main import app

# ── Fixtures ───────────────────────────────────────────────────────────────
@pytest.fixture
def client():
    """Test client with a mock model loaded."""
    mock_pipeline = Pipeline([
        ("scaler", StandardScaler()),
        ("model", GradientBoostingClassifier(n_estimators=10, random_state=42))
    ])
    X_dummy = np.random.rand(100, 6)
    y_dummy = np.random.randint(0, 2, 100)
    mock_pipeline.fit(X_dummy, y_dummy)

    with patch("app.main.model", mock_pipeline):
        with TestClient(app) as c:
            yield c

LEGIT_TRANSACTION = {
    "amount": 25.00,
    "hour_of_day": 14,
    "distance_from_home": 2.5,
    "num_transactions_24h": 2,
    "is_foreign": False,
    "is_online": False,
}

SUSPICIOUS_TRANSACTION = {
    "amount": 1200.00,
    "hour_of_day": 3,
    "distance_from_home": 250.0,
    "num_transactions_24h": 12,
    "is_foreign": True,
    "is_online": True,
}

# ── Tests ──────────────────────────────────────────────────────────────────
def test_health_check(client):
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"
    assert data["model_loaded"] is True

def test_predict_legit(client):
    response = client.post("/predict", json=LEGIT_TRANSACTION)
    assert response.status_code == 200
    data = response.json()
    assert "is_fraud" in data
    assert "fraud_probability" in data
    assert "risk_level" in data
    assert "transaction_id" in data
    assert 0.0 <= data["fraud_probability"] <= 1.0

def test_predict_suspicious(client):
    response = client.post("/predict", json=SUSPICIOUS_TRANSACTION)
    assert response.status_code == 200
    data = response.json()
    assert data["risk_level"] in ["LOW", "MEDIUM", "HIGH"]

def test_predict_invalid_amount(client):
    bad = {**LEGIT_TRANSACTION, "amount": -50}
    response = client.post("/predict", json=bad)
    assert response.status_code == 422  # Validation error

def test_predict_invalid_hour(client):
    bad = {**LEGIT_TRANSACTION, "hour_of_day": 25}
    response = client.post("/predict", json=bad)
    assert response.status_code == 422

def test_root(client):
    response = client.get("/")
    assert response.status_code == 200
