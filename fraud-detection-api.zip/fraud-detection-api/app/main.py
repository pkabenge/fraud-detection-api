"""
app/main.py
-----------
FastAPI ML inference API for real-time fraud detection.
"""

import os
import time
import logging
from contextlib import asynccontextmanager

import joblib
import numpy as np
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, validator

# ── Logging ────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)
logger = logging.getLogger(__name__)

# ── Model loading ──────────────────────────────────────────────────────────
MODEL_PATH = os.getenv("MODEL_PATH", "model/fraud_model.pkl")
model = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Load model on startup, release on shutdown."""
    global model
    logger.info(f"Loading model from {MODEL_PATH} ...")
    model = joblib.load(MODEL_PATH)
    logger.info("Model loaded successfully.")
    yield
    logger.info("Shutting down — releasing model.")
    model = None

# ── App ────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="Fraud Detection API",
    description="Real-time ML inference API for transaction fraud detection. "
                "Built with FastAPI, scikit-learn, and GradientBoosting.",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Schemas ────────────────────────────────────────────────────────────────
class TransactionRequest(BaseModel):
    amount: float = Field(..., gt=0, description="Transaction amount in USD")
    hour_of_day: int = Field(..., ge=0, le=23, description="Hour of transaction (0-23)")
    distance_from_home: float = Field(..., ge=0, description="Distance from home location in km")
    num_transactions_24h: int = Field(..., ge=0, description="Number of transactions in last 24 hours")
    is_foreign: bool = Field(..., description="Whether transaction is in a foreign country")
    is_online: bool = Field(..., description="Whether transaction is online")

    class Config:
        schema_extra = {
            "example": {
                "amount": 450.00,
                "hour_of_day": 3,
                "distance_from_home": 120.5,
                "num_transactions_24h": 8,
                "is_foreign": True,
                "is_online": True,
            }
        }

class PredictionResponse(BaseModel):
    transaction_id: str
    is_fraud: bool
    fraud_probability: float = Field(..., description="Probability of fraud (0.0 - 1.0)")
    risk_level: str = Field(..., description="LOW | MEDIUM | HIGH")
    latency_ms: float

class HealthResponse(BaseModel):
    status: str
    model_loaded: bool
    version: str

# ── Helpers ────────────────────────────────────────────────────────────────
def risk_level(prob: float) -> str:
    if prob < 0.3:
        return "LOW"
    elif prob < 0.7:
        return "MEDIUM"
    return "HIGH"

def features_to_array(req: TransactionRequest) -> np.ndarray:
    return np.array([[
        req.amount,
        req.hour_of_day,
        req.distance_from_home,
        req.num_transactions_24h,
        int(req.is_foreign),
        int(req.is_online),
    ]])

# ── Routes ─────────────────────────────────────────────────────────────────
@app.get("/health", response_model=HealthResponse, tags=["Health"])
def health_check():
    """Liveness + readiness probe endpoint for Kubernetes."""
    return HealthResponse(
        status="ok",
        model_loaded=model is not None,
        version="1.0.0",
    )

@app.post("/predict", response_model=PredictionResponse, tags=["Inference"])
def predict(request: TransactionRequest, req: Request):
    """
    Run fraud detection inference on a single transaction.
    Returns fraud probability, binary label, and risk tier.
    """
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded.")

    start = time.perf_counter()
    X = features_to_array(request)

    prob = float(model.predict_proba(X)[0][1])
    label = prob >= 0.5
    latency = round((time.perf_counter() - start) * 1000, 3)

    import uuid
    txn_id = str(uuid.uuid4())

    logger.info(
        f"txn={txn_id} | fraud={label} | prob={prob:.4f} | "
        f"risk={risk_level(prob)} | latency={latency}ms"
    )

    return PredictionResponse(
        transaction_id=txn_id,
        is_fraud=label,
        fraud_probability=round(prob, 4),
        risk_level=risk_level(prob),
        latency_ms=latency,
    )

@app.get("/", tags=["Root"])
def root():
    return {"message": "Fraud Detection API is running. Visit /docs for the Swagger UI."}
